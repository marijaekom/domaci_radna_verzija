<!DOCTYPE html>
<html>
<head>
	<title>Registracija</title>
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<meta charset="utf-8">
</head>
<body>
	<div class="my-form">
	<h2>Registracija</h2>
	<form action="logika/registrujse.php" method="post">
		<input type="email" name="email" placeholder="Unesi e-mail" required>
		<input type="password" name="password" placeholder="Unesi  lozinku" required>
		<input type="password" name="password_repeat" placeholder="Ponovo unesi  lozinku" required>
		<input type="text" name="ime_prezime" placeholder="Unesi ime i prezime" required>
		<input type="text" name="telefon" placeholder="Unesi broj telefona" required>
		<input type="submit" value="Registruj se" class="my-button">
		<?php if (isset($_GET['pass'])): ?>
			<p style="color:red; font-weight: bold">Lozinke se ne podudaraju.</p>
		<?php endif ?>
		<?php if (isset($_GET['error'])): ?>
			<p style="color:red; font-weight: bold">Već je registrovan nalog sa tom imejl adresom.</p>
		<?php endif ?>
	</form>
	<a href="index.php">Prijavi se</a>
	<a href="lozinka.php">Promeni lozinku</a>
	</div>
</body>
</html>