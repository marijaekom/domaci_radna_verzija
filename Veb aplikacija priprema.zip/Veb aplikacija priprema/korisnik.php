<?php
	session_start();
	if (!isset($_SESSION['id'])){
		header('Location: index.php');
		die();
	}

	require_once __DIR__ . '/tabele/Poruka.php';
	$poruke = Poruka::sve_poruke();

	require_once __DIR__ . '/tabele/Korisnik.php';
	$korisnici = Korisnik::svi_korisnici();

?>


<!DOCTYPE html>
<html>
<head>
	<title>Razmena poruka</title>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/main.js"></script>
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<meta charset="utf-8">
</head>
<body>
	<div class="my-form">
		<a href="logika/odjavise.php">Odjavi se</a>
		<h2>Razmena poruka</h2>
		<form method="post" action="logika/ostaviporuku.php" id="ostavi_poruku">
			<input type="text" name="naslov" id="naslov" placeholder="Unesite naslov poruke" required>
			<textarea name="sadrzaj" id="sadrzaj" placeholder="Unesite vašu poruku." maxlength="160" required></textarea>
			<p>Izaberite korisnika za razmenu poruka.</p>
			<select name="izaberi" id="izaberi" required>
				<option value="izaberi" id="izaberi">Izaberi</option>
				<?php foreach ($korisnici as $korisnik): ?>
				<?php if ($korisnik->id != $_SESSION['id']) :?>
					<option value="<?=$korisnik->id?>"><?=$korisnik->ime_prezime . " ". $korisnik->id?></option>
				<?php endif ?>
				<?php endforeach ?>
			</select>
			<input type="hidden" id="izabran_korisnik" name="izabran_korisnik" value="0">
        <script>
            $(document).ready(function(){
            $('#izaberi').change(function(){
                var primalac = $(this).val();
                $('#izaberi').val(primalac);
                $('#izabran_korisnik').val(primalac); 
       		 	});
        	});  
        </script>
			<div class="radio-buttons">
				<span>Hitno</span><input type="radio" name="prioritet" value="1" required>
				<span>Nije hitno</span><input type="radio" name="prioritet" value="0">
			</div>
			<input type="submit" value="Pošalji" class="my-button" id="posalji">
			<?php if (isset($_GET['select'])): ?>
				<p class="red-text">Niste izabrali primaoca poruke.</p>
			<?php endif ?>
		</form>
	</div>

	<div id="poruke" class="my-message">

		<?php foreach ($poruke as $poruka): ?> 

		<div class="message-info">
			<p class="ime-prezime"><?= $poruka->korisnik()->ime_prezime ?></p>
			<p><?= $poruka->naslov ?></p>
			<p><?= $poruka->vreme() ?></p>
			<p><?= $poruka->primalac ?></p>
			<?php if ( $poruka->korisnik()->id==$_SESSION['id']): ?>
				<a href="logika/obrisiporuku.php?id=<?=
					 $poruka->id ?>" class="btn delete-btn" id="obrisi">Obriši</a>
			<?php endif ?>
			<?php if ( $poruka->korisnik()->id!=$_SESSION['id']): ?>
				<?php if ( $poruka->procitano==0): ?>
						<a href="logika/procitajporuku.php?id=<?=
					 $poruka->id?>" class="btn">Pročitaj</a>
					<?php endif ?>
				<?php endif ?>
		</div>
		<div class="message-content">
			<?php if($poruka->prioritet=='1'): ?>
			<p class="red-text"><?= $poruka->sadrzaj ?></p>
			<?php endif ?>
			<?php if($poruka->prioritet=='0'): ?>
			<p class="green-text"><?= $poruka->sadrzaj ?></p>
			<?php endif ?>
			<?php if ( $poruka->procitano==1): ?>
						<p class="procitano">Pročitano</p>
			<?php endif ?>
		</div>

		<?php endforeach ?>

		

	</div>


</body>
</html>