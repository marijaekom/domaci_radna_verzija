-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2019 at 11:50 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `veb_aplikacija`
--
CREATE DATABASE IF NOT EXISTS `veb_aplikacija` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `veb_aplikacija`;

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ime_prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `telefon` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `email`, `password`, `ime_prezime`, `telefon`) VALUES
(1, 'maja@mail.com', 'passmaja2', 'Maja Maja', '065444555'),
(2, 'marija@gmail.com', '48fb10b15f3d44a09dc82d02b06581e0c0c69478c9fd2cf8f9093659019a1687baecdbb38c9e72b12169dc4148690f87467f9154f5931c5df665c6496cbfd5f5', 'Marija Marija', '064123456'),
(3, 'nemanja@gmail.com', 'nemanja', 'Nemanja Nemanja', '06412589'),
(5, 'ivana@mail.com', 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e', 'Ivana Ivana', '000000'),
(9, 'neko@gmail.com', '86d656a538e91cb52bf72259f574b353549d19c842761de266a7dcc81d1361d1cead787fd610a2298120a37a8a96fd0da195bdef357629f1b5439bd70fac8419', 'Neko Neko', '123'),
(10, 'jovan@gmail.com', 'c13da54705e91a6c9c83a5de4f551a263c2c59ef4a4f2ec5d176f38bb6a015891d84e3186fab8d62c3ca6d1678e77e570cc06cd38429bb23f532f7ea0c502257', 'Jovan Jovanovic', '123'),
(11, 'tanja@gmail.com', 'a7ad61108f53eb0f4e4716a2cacdb4e9bd5a60a7ee35559a1d38f97ab9a81b50eda648cd7844eb043cf12a6532e981b372b48239c32f88ba76c8e79220791ab2', 'Tanja Jovanovic', '064123456'),
(12, 'tim@gmail.com', '565a2e7a1d7a47e6a47d5f5f0aae970c163116c5447557d7a496bbb74e072cad30b800eca0f093e889f18520661806801d926eada62a757e7210878bc87b91e2', 'Tim Tim', '123');

-- --------------------------------------------------------

--
-- Table structure for table `poruke`
--

CREATE TABLE `poruke` (
  `id` int(10) UNSIGNED NOT NULL,
  `naslov` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sadrzaj` varchar(160) COLLATE utf8_unicode_ci NOT NULL,
  `vreme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `korisnik_id` int(10) UNSIGNED NOT NULL,
  `prioritet` int(11) NOT NULL,
  `primalac` int(11) UNSIGNED NOT NULL,
  `procitano` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `poruke`
--

INSERT INTO `poruke` (`id`, `naslov`, `sadrzaj`, `vreme`, `korisnik_id`, `prioritet`, `primalac`, `procitano`) VALUES
(132, 'Naslov komentara', 'Ovo je tekst poruke. Ovo je tekst poruke. Ovo je tekst poruke. Ovo je tekst poruke. Ovo je tekst poruke. ', '2019-08-22 21:48:54', 12, 1, 10, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `poruke`
--
ALTER TABLE `poruke`
  ADD PRIMARY KEY (`id`),
  ADD KEY `korisnik_id` (`korisnik_id`),
  ADD KEY `primalac` (`primalac`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `poruke`
--
ALTER TABLE `poruke`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
