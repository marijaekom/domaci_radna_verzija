<?php

if (!isset($_POST['email'])){
	header('Location: ../registracija.php');
	die();
}

$email = $_POST['email'];
$password = $_POST['password'];
$password_repeat = $_POST['password_repeat'];
$ime_prezime = $_POST['ime_prezime'];
$telefon = $_POST['telefon'];

if ($password !== $password_repeat){
	header('Location: ../registracija.php?pass=0');
	die();
}

require_once __DIR__ . '/../tabele/Korisnik.php';
$id = Korisnik::registracija($email, $password, $ime_prezime, $telefon);

if ($id > 0){
	header('Location: ../index.php');
	die();
}
else{
	header('Location: ../registracija.php?error=0');
	die();
}//ovo ne radi//


