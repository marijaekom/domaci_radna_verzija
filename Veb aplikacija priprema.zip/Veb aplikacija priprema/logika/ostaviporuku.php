<?php
session_start();

if (!isset($_SESSION['id'])) {
	header('Location: ../index.php');
	die();
}

if (!isset($_POST['naslov'])) {
	header('Location: ../korisnik.php');
	die();
}

 if ($_POST['izaberi'] == 'izaberi'){
 	header('Location: ../korisnik.php?select=0');
 	die();
 }

 if (!isset($_POST['izabran_korisnik'])){
		header('Location: ../korisnik.php?select=0');
		die();
	}


require_once __DIR__ . '/../tabele/Poruka.php';

$id = Poruka::ostavi_poruku($_POST['naslov'], $_POST['sadrzaj'], $_SESSION['id'], $_POST['prioritet'], $_POST['izabran_korisnik']);

header('Location: ../korisnik.php');
die();

