<?php
define('HOST', 'localhost');
define('DBNAME', 'veb_aplikacija');
define('USER', 'root');
define('PASS', '');